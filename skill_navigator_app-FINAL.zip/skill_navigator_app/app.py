import firebase_admin
from firebase_admin import credentials, firestore
import google.generativeai as genai
from flask import Flask, render_template, redirect, url_for, request, session

# Initialize Firebase
cred = credentials.Certificate("key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

app = Flask(__name__)
app.secret_key = 'VVK@6300798983419949'

# Google AI API configuration
GOOGLE_API_KEY = "AIzaSyDpDxfr78tAW4K-uGLVHgd1punM9bCUUcY"
genai.configure(api_key=GOOGLE_API_KEY)

model = genai.GenerativeModel('gemini-pro')


@app.route('/')
def home():
    return render_template('login.html')


@app.route('/signup')
def signup():
    return render_template('index.html')


@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']
    account_type = request.form['account_type']

    if account_type == 'admin':
        if email == 'ymini@admin.com' and password == 'admin':
            session['email'] = email
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('home'))

    elif account_type == 'user':
        user_ref = db.collection('ymini-UserData').where('email', '==', email).limit(1).get()
        if user_ref:
            user = user_ref[0].to_dict()
            if user['password'] == password:
                session['email'] = email
                return redirect(url_for('user_dashboard'))
        return redirect(url_for('home'))

    return redirect(url_for('home'))



# @app.route('/admin_dashboard')
# def admin_dashboard():
#     if 'email' not in session or session['email'] != 'ymini@admin.com':
#         return redirect(url_for('home'))  # Redirect to home if not authorized
    
#     users_ref = db.collection('ymini-UserData').stream()
#     tracks = {user.to_dict().get('selected_track', 'No track selected') for user in users_ref}

#     return render_template('admin_dashboard.html', tracks=tracks)  # Render the correct template



@app.route('/admin_dashboard')
def admin_dashboard():
    if 'email' not in session:
        return redirect(url_for('home'))
    
    users_ref = db.collection('ymini-UserData').stream()
    tracks = {user.to_dict().get('selected_track', 'No track selected') for user in users_ref}

    return render_template('dashboard.html', tracks=tracks)


# @app.route('/user_dashboard')
# def user_dashboard():
#     if 'email' not in session:
#         return redirect(url_for('home'))
    
#     email = session['email']
#     user_ref = db.collection('ymini-UserData').where('email', '==', email).limit(1).get()
#     if user_ref:
#         user_data = user_ref[0].to_dict()
#         selected_track = user_data.get('selected_track', None)

#         assessments_ref = db.collection('Assessments').where('track', '==', selected_track).get()
#         assessments = [assessment.to_dict() for assessment in assessments_ref]

#         return render_template('user_dashboard.html', user_name=user_data['name'], assessments=assessments)
#     return redirect(url_for('home'))

@app.route('/user_dashboard')
def user_dashboard():
    if 'email' not in session:
        return redirect(url_for('home'))

    email = session['email']
    user_ref = db.collection('ymini-UserData').where('email', '==', email).limit(1).get()
    
    if user_ref:
        user_data = user_ref[0].to_dict()
        selected_track = user_data.get('selected_track', None)

        # Fetch assessments related to the selected track
        assessments_ref = db.collection('Assessments').where('track', '==', selected_track).get()
        assessments = [assessment.to_dict() for assessment in assessments_ref]

        # Fetch the score for the current user and track
        scores_ref = db.collection('scores').where('email', '==', email).where('track', '==', selected_track).get()
        if scores_ref:
            user_score = scores_ref[0].to_dict().get('score', "-")  # Use "-" if no score found
        else:
            user_score = "-"  # Default to "-" if no score exists

        return render_template('user_dashboard.html', user_name=user_data['name'], assessments=assessments, user_score=user_score)
    
    return redirect(url_for('home'))



# @app.route('/track/<track_name>')
# def users_by_track(track_name):
#     if 'email' not in session:
#         return redirect(url_for('home'))
    
#     users_ref = db.collection('ymini-UserData').where('selected_track', '==', track_name).stream()
#     users = [user.to_dict() for user in users_ref]

#     return render_template('users_by_track.html', track_name=track_name, users=users)

@app.route('/track/<track_name>')
def users_by_track(track_name):
    if 'email' not in session:
        return redirect(url_for('home'))
    
    # Retrieve users with the specified track from Firestore
    users_ref = db.collection('ymini-UserData').where('selected_track', '==', track_name).stream()
    
    # Convert user data to dictionary format and set default feedback to '-'
    users = []
    for user in users_ref:
        user_data = user.to_dict()
        user_data['feedback'] = user_data.get('feedback', '-')  # Set default to '-' if feedback is missing
        users.append(user_data)

    return render_template('users_by_track.html', track_name=track_name, users=users)



@app.route('/add_assessment', methods=['POST'])
def add_assessment():
    if 'email' not in session:
        return redirect(url_for('home'))
    
    track = request.form['track']
    assessment_description = request.form['assessment_description']

    assessment_data = {
        'track': track,
        'assessment_description': assessment_description
    }

    db.collection('Assessments').add(assessment_data)

    return redirect(url_for('admin_dashboard'))


# @app.route('/submit_assessment', methods=['POST'])
# def submit_assessment():
#     track = request.form['track']
#     assessment_description = request.form['assessment_description']
#     work = request.form['work']
#     email = session.get('email')

#     # Use Google Gemini-Pro model to evaluate the answer
#     prompt = f"""
#     Consider your are an excellent question answer evaluator.
#     Based on the question and answer provided:
#     - Question: {assessment_description}
#     - Answer: {work}
    
#     Evaluate the answer on a scale from 0 to 10, with 10 being completely accurate and relevant.
#     Output only the float score with no additional text or explanations.
#     """
    
#     response = model.generate_content(prompt)
#     new_score = float(response.text.strip())

#     # Check if a score already exists and calculate the average if necessary
#     scores_ref = db.collection('scores').where('email', '==', email).where('track', '==', track).where('assessment_description', '==', assessment_description).get()

#     if scores_ref:
#         current_score = scores_ref[0].to_dict()['score']
#         average_score = (current_score + new_score) / 2
#         scores_ref[0].reference.update({'score': average_score})
#     else:
#         db.collection('scores').add({
#             'email': email,
#             'track': track,
#             'assessment_description': assessment_description,
#             'score': new_score
#         })

#     return redirect(url_for('user_dashboard'))

@app.route('/process', methods=['POST'])
def process():
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    mobile = request.form['mobile']
    skills = request.form['skills']
    languages = request.form['languages']
    certifications = request.form['certifications']

    prompt = f"""
    Based on the following information:
    - Skills: {skills}
    - Programming Languages: {languages}
    - Certifications: {certifications}

    From the list [Python, Java, Golang, DevOps, Fullstack], return only the names of the one or two most relevant tracks. 
    Please output only the track names with no additional text or explanations.
    """

    response = model.generate_content(prompt)
    tracks = response.text.strip().split("\n")

    return render_template('result.html', name=name, email=email, password=password, mobile=mobile, skills=skills, languages=languages, certifications=certifications, tracks=tracks)

@app.route('/submit_assessment', methods=['POST'])
def submit_assessment():
    track = request.form['track']
    assessment_description = request.form['assessment_description']  # You can keep this for logging purposes if needed
    work = request.form['work']
    email = session.get('email')

    # Use Google Gemini-Pro model to evaluate the answer
    prompt = f"""
    Consider you are an excellent question answer evaluator.
    Based on the question and answer provided:
    - Question: {assessment_description}
    - Answer: {work}
    
    Evaluate the answer on a scale from 0 to 10, with 10 being completely accurate and relevant.
    Output only the float score with no additional text or explanations.
    """
    
    response = model.generate_content(prompt)
    new_score = float(response.text.strip())

    # Check if a score already exists for the user and track
    scores_ref = db.collection('scores').where('email', '==', email).where('track', '==', track).get()

    if scores_ref:
        # If a score exists, update the score with the average
        current_score = scores_ref[0].to_dict()['score']
        average_score = (current_score + new_score) / 2
        scores_ref[0].reference.update({'score': average_score})
    else:
        # Create a new score record if none exists
        db.collection('scores').add({
            'email': email,
            'track': track,
            'score': new_score
        })

    return redirect(url_for('user_dashboard'))


@app.route('/save_to_firebase', methods=['POST'])
def save_to_firebase():
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    mobile = request.form['mobile']
    skills = request.form['skills']
    languages = request.form['languages']
    certifications = request.form['certifications']
    selected_track = request.form['selected_track']

    document_id = f"{name}_{mobile}"

    user_data = {
        'name': name,
        'email': email,
        'password': password,
        'mobile': mobile,
        'skills': skills,
        'languages': languages,
        'certifications': certifications,
        'selected_track': selected_track
    }

    db.collection('ymini-UserData').document(document_id).set(user_data)

    return render_template('success.html', message=f"Data for {name} with the selected track '{selected_track}' has been saved to Our Database successfully!")


@app.route('/logout')
def logout():
    session.pop('email', None)
    return redirect(url_for('home'))
# @app.route('/logout', methods=['POST'])
# def logout():
#     session.pop('email', None)
#     return redirect(url_for('home'))

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    if 'email' not in session:
        return redirect(url_for('home'))
    
    email = session['email']
    feedback = request.form['feedback']
    
    # Update the user document with feedback in Firestore
    user_ref = db.collection('ymini-UserData').where('email', '==', email).limit(1).get()
    if user_ref:
        user_doc = user_ref[0].reference
        user_doc.update({'feedback': feedback})
    
    return redirect(url_for('user_dashboard'))




if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True)







